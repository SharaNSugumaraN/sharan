from django.contrib import admin
from .models import acc_login,acc_lo
from .models import admina,personal_details,Father_details,scholarship_details,referencedetails
from .models import Mother_details,otherdetails,amenities
# Register your models here.

admin.site.register(admina)
admin.site.register(personal_details)
admin.site.register(Father_details)
admin.site.register(Mother_details)
admin.site.register(otherdetails)
admin.site.register(referencedetails)
admin.site.register(amenities)
admin.site.register(scholarship_details)