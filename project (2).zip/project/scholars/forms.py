
from django.forms import ModelForm
from .models import scholarship_details,personal_details,Father_details,Mother_details
from .models import brotherdetails,Propertydetails,amenities,otherdetails,referencedetails
from django import forms
from django.contrib.auth.models import User




class scholarship_detail(forms.ModelForm):
    class Meta:
        model = scholarship_details
        fields=['scholarship_name','scholarship_provider','scholarship_availability']



class personal(forms.ModelForm):
    class Meta:
        model = personal_details
        fields = ['id','batch','registerno','name','college_emailid','personal_emailid','contact_no','address','hall','hallname','tenth_precentage','twelveth_percentage','gender']


class father(forms.ModelForm):
    class Meta:
        model = Father_details
        fields = ['name','living','Age','education','occupation','work_status','yearly_income','organization_address','contact_no','emailid','Dateofretirement']

        
class mother(forms.ModelForm):
   class Meta:
         model = Mother_details
         fields = ['name','living','age','education','occupation','work_status','yearly_income','organization_address','contact_no','emailid','Dateofretirement']


class brother1(forms.ModelForm):
    class Meta:
        model = brotherdetails   
        fields = ['bro1name','bro1age','bro1education','bro1schoolorcollege','bro1martial_status','bro1occupation_organization','bro1income']      


class brother2(forms.ModelForm):
    class Meta:
        model = brotherdetails   
        fields = ['bro2name','bro2age','bro2education','bro2schoolorcollege','bro2martial_status','bro2occupation_organization','bro2income']


class brother3(forms.ModelForm):
    class Meta:
        model = brotherdetails   
        fields = ['bro3name','bro3age','bro3education','bro3schoolorcollege','bro3martial_status','bro3occupation_organization','bro3income']                


class propertydetails(forms.ModelForm):
    class Meta:
        model =  Propertydetails
        fields = ['property','area','location','incomethroughrental','livinginownhouse','rentofrenthouse']


class Amenities(forms.ModelForm):
    class Meta:
        model = amenities
        fields = ['computer','fourwheelerr','twowheeler','airconditioner','washingmachine','refrigirator','modeldetails']         


class other(forms.ModelForm):
    class Meta:
        model = otherdetails
        fields = ['firstgeneratinslearner','scholarshiporfundrecieved','agencyawardingscholarship','natureofagency','scholarshipperiod','amount','isscholarsipcontinuing','financialmeans']         

class reference(forms.ModelForm):
    class Meta:
        model = referencedetails
        fields = ['nameofreference1','occupationofreference1','addressofreference1','nameofreference2','occupationofreference2','addressofreference2']         
