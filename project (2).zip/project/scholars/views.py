from django.shortcuts import render,redirect
from django.contrib import messages
# from django.contrib.auth.forms import UserCreationForm
from .forms import scholarship_detail,personal,father,mother
from .forms import propertydetails,Amenities,other,reference 
from django.contrib.auth.models import User
from .models import admina,personal_details,Father_details,scholarship_details,brotherdetails
from .models import Mother_details
from django.contrib.auth import authenticate,login,logout
import nltk
import random


def home(request):
   return render(request,'home.html')



def log(request):
  
 if request.method == 'POST' :
    username = request.POST.get('uname')
    password = request.POST.get('pwd')

    user = authenticate(request, username=username, password=password)

    if user is not None:
     login(request, user)
     return redirect('students')
    
    else:
      messages.info(request, 'Invalid username or password')
   
 return render(request,'login.html')




def reg(request):

 if request.method == 'POST':
    first_name = request.POST['fname']
    last_name = request.POST['lname']
    username = request.POST['uname']
    email = request.POST['email']
    password = request.POST['pwd']
    confirm_password =request.POST['cpwd']
    
    if password == confirm_password:
        if User.objects.filter(username=username).exists():
           messages.info(request,'Username taken')
           return redirect('register')
        elif User.objects.filter(email=email).exists():
           messages.info(request,'Email already exists')
           return redirect('register')
        else:
           user = User.objects.create_user(username=username,password=password,email=email,first_name=first_name,last_name=last_name)
           user.set_password(password)
           user.save()
           return render(request,'login.html')
    else:
     return redirect('/')
    
 else:
   return render(request,'register.html')




def student(request):
   form = personal()
   
   if request.method == 'POST':
     form = personal(request.POST)  
     if form.is_valid():
      form.save()
      return redirect("fatherdetails")

   context ={'form' : form }
   
   return render(request,'personalinsert.html',context)




def fatherdetails(request):
  form = father()

  if request.method == 'POST':
    form = father(request.POST)
    if form.is_valid():
      form.save()
    return redirect("motherdetails")
    
  
  context={'form': form}
    
  return render(request,'fatherdetails.html',context) 




def motherdetails(request):
  form=mother()

  if request.method == 'POST':
    form=mother(request.POST)
    if form.is_valid():
      form.save()
    return redirect("property1")
  context = {'form': form}
   
  return render(request,'motherdetails.html',context) 

"""
def brother(request):
   # personal = brotherdetails.objects.all()
   global bro 
   if request.method == 'POST': 
    bro= request.POST['bro']

    
    if bro == "NA":
      count = brotherdetails(noofbrothers=bro)
      count.save()
      return redirect("sister")

    elif bro == 1:
      count = brotherdetails(noofbrothers=bro)
      count.save()
      return redirect("brother1")

   #  context={'bro' : personal}
   return render(request,'brothercount.html')

def brother1(request):

    if bro == "1":
   #   .........................
     return redirect("sister")

    if bro == "2":
     return redirect("/")

  
    return render(request,'brother1.html')
   


def brother2(request,pk):

    if bro == 2:
   #   .................

     return redirect("sister")

    if bro == 3 :
     return redirect("brother3")

  
    return render(request,'brother2.html')


def brother3(request,pk):

    if bro == 3:
   #   .................

     return redirect("sister")

    
    return render(request,'brother3.html')

def sister(request):


  
   return render(request,'sistercount.html')
   
"""



def property1(request):
  
  form = propertydetails()

  if request.method == 'POST':
     form = propertydetails(request.POST)
     if form.is_valid():
      form.save()
      return redirect("property2") 
  context = {'form' : form }

  return render(request,'property.html',context)



def property2(request):
  
  form = Amenities()

  if request.method == 'POST':
     form = Amenities(request.POST)
     if form.is_valid():
      form.save()
      return redirect("otherdetails")
  context = {'form' : form }

  return render(request,'property2.html',context)


def Otherdetails(request):
  
  form = other()

  if request.method == 'POST':
     form = other(request.POST)
     if form.is_valid():
      form.save()
      return redirect("referencedetails")
  context = {'form' : form }

  return render(request,'otherdetails.html',context)


def Referencedetails(request):
  
  form = reference()

  if request.method == 'POST':
     form = reference(request.POST)
     if form.is_valid():
      form.save()
      return redirect("/")
  context = {'form' : form }

  return render(request,'reference.html',context)



def admin(request):
  
   Admin=admina.objects.all()
   count=Admin.count()

   students_count=personal_details.objects.all()
   stud_count=students_count.count()

   personal = personal_details.objects.all()

   male = personal_details.objects.filter(gender='male').count()
   male = int(male) 

   female = personal_details.objects.filter(gender='female').count() 
   female = int(female)

   gender= [male,female]

   context={'count' : count, 'scount' : stud_count, 'personal' : personal, 'gender' : gender,}

   return render (request,"dashboard.html",context)



def student_view(request,pk_test):
   
   sview = personal_details.objects.get(id=pk_test)
 
   
   fdetails = Father_details.objects.all()

   # mdetails = Father_details.objects.all()
  
   context = {'sview' : sview, 'personal' : sview,'fdetails' : fdetails}
   return render(request,'student_view.html', context)




def delete(request,pk_test):
  
   sview = personal_details.objects.get(id=pk_test)
   
   if request.method == "POST":
     sview.delete()
     return redirect("dashboard")

   context = {'item' : sview}
   
   return render(request,'delete.html', context)




def allstud(request):

    students_count=personal_details.objects.all()
    
    stud_count=students_count.count()
    
    personal = personal_details.objects.all()

    
    male = personal_details.objects.filter(gender='male').count()
    male = int(male)

    female = personal_details.objects.filter(gender='female').count() 
    female = int(female)

    gender_no= [male,female]
    
    context = {'stud_count' : stud_count, 'personal' : personal,'gender_no' : gender_no}
    return render(request,'allstudents.html',context)




def scholar(request):
   
   form = scholarship_detail()
   schola = scholarship_details.objects.all()

   if request.method == 'POST':
     form = scholarship_detail(request.POST)  
     if form.is_valid():
      form.save()
      return redirect('scholarship')

   context ={'form' : form , 'schola' : schola}
   
   return render(request,'scholarship.html',context)




def updatescholar(request,pk):
  
  id1 = scholarship_details.objects.get(id=pk)
  form = scholarship_detail(instance=id1)
  
  if request.method == 'POST':
     form = scholarship_detail(request.POST, instance=id1)  
     if form.is_valid():
       form.save()
       return redirect('scholarship')
   
  
  context = {'form' : form}

  return render(request,'update.html',context)
  



def deletescholar(request,pk):
  
   sview1 = scholarship_details.objects.get(id=pk)
   
   if request.method == "POST":
     sview1.delete()
     return redirect("scholarship")

   context = {'item' : sview1}
   
   return render(request,'deletescholar.html', context)




template = "Hello, my name is {name}. I am studying in MCA {batch} batch. My register number is {reg}.My contact number is {phone}. I live in {adress}.I have secured {tenper} percentage in tenth standard and {tper} percentage in twelveth. "

# NLTK initialization
#nltk.download('punkt')

def writtentext(request,pk):

   people = personal_details.objects.get(id=pk)
    
   generated_text = []
    
   # for person in people:
   sentence = template.format(name=people.name, batch=people.batch, reg=people.registerno,phone=people.contact_no,adress=people.address,tper=people.twelveth_percentage,tenper=people.tenth_precentage)
   generated_text.append(sentence)
       
   sentence = generated_text

   return render(request, 'nlg.html', {'random_sentence': sentence})

