from django.db import models

# Create your models here.

class acc_login(models.Model):
    username=models.CharField(max_length=100,null=True)
    password=models.CharField( max_length=50,null=True)

  
class acc_register(models.Model):
    USERROLE=(('Faculty','faculty'),
              ('Student','student'))
    username=models.CharField(max_length=100,null=True)
    emailid=models.EmailField(max_length=254,null=True)
    phonenumber=models.IntegerField(null=True)
    userrole=models.CharField(max_length=100,null=True,choices=USERROLE)
    password=models.CharField( max_length=50,null=True)
    confirmpassword=models.CharField( max_length=50,null=True)


class acc_lo(models.Model):
    username=models.CharField(max_length=100,null=True)
    password=models.CharField( max_length=50,null=True)


class admina(models.Model):
    username=models.CharField(max_length=100,null=True)
    password=models.CharField( max_length=50,null=True)




class personal_details(models.Model):
     id=models.IntegerField()
     batch=models.CharField(max_length=100,null=True)
     registerno=models.IntegerField(primary_key=True)
     name=models.CharField(max_length=100,null=True)
     college_emailid=models.EmailField(null=True)
     personal_emailid=models.EmailField(null=True)
     contact_no=models.IntegerField(null=True)
     address=models.CharField(max_length=200,null=True)
     hall=models.CharField(max_length=100,null=True)
     hallname=models.CharField(max_length=100,null=True)
     tenth_precentage=models.IntegerField(null=True)
     twelveth_percentage=models.IntegerField(null=True)
     gender=models.CharField(max_length=100,null=True)

     def __str__(self):
      return self.name


class Father_details(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=100,null=True)
    living=models.CharField(max_length=100,null=True)
    Age=models.IntegerField(null=True)
    education=models.CharField(max_length=100,null=True)
    occupation=models.CharField(max_length=100,null=True)
    work_status=models.CharField(max_length=100,null=True)
    yearly_income=models.IntegerField(null=True)
    organization_address=models.CharField(max_length=100,null=True)
    contact_no=models.IntegerField(null=True)
    emailid= models.EmailField( max_length=254,null=True)
    Dateofretirement=models.DateField(null=True)

class Mother_details(models.Model):
     id=models.AutoField(primary_key=True)
     name=models.CharField(max_length=100,null=True)
     living=models.CharField(max_length=100,null=True)
     age=models.IntegerField(null=True)
     education=models.CharField(max_length=100,null=True)
     occupation=models.CharField(max_length=100,null=True)
     work_status=models.CharField(max_length=100,null=True)
     yearly_income=models.IntegerField(null=True)
     organization_address=models.CharField(max_length=100,null=True)
     contact_no=models.IntegerField(null=True)
     emailid= models.EmailField( max_length=254,null=True)
     Dateofretirement=models.DateField(null=True)

      
class Brother_details(models.Model):
     name=models.CharField(max_length=100,null=True)
     age=models.IntegerField(null=True)
     education=models.CharField(max_length=100,null=True)
     schoolorcollege=models.CharField(max_length=100,null=True)
     martial_status=models.CharField(max_length=100,null=True)
     occupation_organization=models.CharField(max_length=100,null=True)
     income=models.IntegerField(null=True)
 

class Sister_details(models.Model):
     name=models.CharField(max_length=100,null=True)
     age=models.IntegerField(null=True)
     education=models.CharField(max_length=100,null=True)
     schoolorcollege=models.CharField(max_length=100,null=True)
     martial_status=models.CharField(max_length=100,null=True)
     occupation_organization=models.CharField(max_length=100,null=True)
     income=models.IntegerField(null=True)
 

class Propertydetails(models.Model):
     id=models.AutoField(primary_key=True)
     property=models.CharField(max_length=100,null=True)
     area=models.IntegerField(null=True)
     location=models.CharField(max_length=100,null=True)
     incomethroughrental=models.CharField(max_length=100,null=True)
     livinginownhouse=models.CharField(max_length=100,null=True)
     rentofrenthouse=models.IntegerField(null=True)
     amenities=models.CharField(max_length=100,null=True)


class amenities(models.Model):
    id=models.AutoField(primary_key=True)
    computer= models.CharField(max_length=100,null=True)
    fourwheelerr= models.CharField(max_length=100,null=True)
    twowheeler= models.CharField(max_length=100,null=True)
    airconditioner= models.CharField(max_length=100,null=True)
    washingmachine= models.CharField(max_length=100,null=True) 
    refrigirator= models.CharField(max_length=100,null=True)
    modeldetails = models.CharField(max_length=100,null=True)

class otherdetails(models.Model):
        id = models.AutoField(primary_key=True)
        firstgeneratinslearner=models.CharField(max_length=100,null=True)
        scholarshiporfundrecieved=models.CharField(max_length=100,null=True)
        agencyawardingscholarship=models.CharField(max_length=100,null=True)
        natureofagency=models.CharField(max_length=100,null=True)
        scholarshipperiod=models.CharField(max_length=100,null=True)
        amount=models.IntegerField(null=True)
        isscholarsipcontinuing=models.CharField(max_length=100,null=True)
        financialmeans=models.CharField(max_length=100,null=True)


class referencedetails(models.Model):
   id = models.AutoField(primary_key=True)
   nameofreference1=models.CharField(max_length=100,null=True)
   occupationofreference1=models.CharField(max_length=100,null=True)
   addressofreference1=models.CharField(max_length=100,null=True)
   nameofreference2=models.CharField(max_length=100,null=True)
   occupationofreference2=models.CharField(max_length=100,null=True)
   addressofreference2=models.CharField(max_length=100,null=True)



class scholarship_details(models.Model):
     id=models.AutoField(primary_key=True)
     scholarship_name=models.CharField(max_length=100,null=True)
     scholarship_provider=models.CharField(max_length=100,null=True)
     scholarship_availability=models.CharField(max_length=100,null=True)
     
     def __str__(self):
      return self.scholarship_name
     


class brotherdetails(models.Model):
     id=models.AutoField(primary_key=True)
     noofbrothers=models.IntegerField()
     bro1name=models.CharField(max_length=100,null=True)
     bro1age=models.IntegerField(null=True)
     bro1education=models.CharField(max_length=100,null=True)
     bro1schoolorcollege=models.CharField(max_length=100,null=True)
     bro1martial_status=models.CharField(max_length=100,null=True)
     bro1occupation_organization=models.CharField(max_length=100,null=True)
     bro1income=models.IntegerField(null=True)
     bro2name=models.CharField(max_length=100,null=True)
     bro2age=models.IntegerField(null=True)
     bro2education=models.CharField(max_length=100,null=True)
     bro2schoolorcollege=models.CharField(max_length=100,null=True)
     bro2martial_status=models.CharField(max_length=100,null=True)
     bro2occupation_organization=models.CharField(max_length=100,null=True)
     bro2income=models.IntegerField(null=True)
     bro3name=models.CharField(max_length=100,null=True)
     bro3age=models.IntegerField(null=True)
     bro3education=models.CharField(max_length=100,null=True)
     bro3schoolorcollege=models.CharField(max_length=100,null=True)
     bro3martial_status=models.CharField(max_length=100,null=True)
     bro3occupation_organization=models.CharField(max_length=100,null=True)
     bro3income=models.IntegerField(null=True)