from django.urls import path
from . import views

urlpatterns = [

    path('',views.home,name="home"),
    path('register/',views.reg,name="register"),
    path('login/',views.log,name="login"),
    path('studentdetails/',views.student,name="students"),
    path('fatherdetails/',views.fatherdetails,name="fatherdetails"),
    path('motherdetails/',views.motherdetails,name="motherdetails"),
    # path('brothercount/',views.brother,name="brother"),
    # path('brother1/',views.brother1,name="brother1"),
    # path('sistercount/',views.sister,name="sister"),
    path('propertydetails1/',views.property1,name="property1"),
    path('propertydetails2/',views.property2,name="property2"),
    path('otherdetails/',views.Otherdetails,name="otherdetails"),
    path('referencedetails/',views.Referencedetails,name="referencedetails"),
    path('dashboard/',views.admin,name="dashboard"),
    path('students/',views.allstud,name="allstudents"),
    path('studentview/<int:pk_test>/',views.student_view,name="student"),
    path('delete/<int:pk_test>/',views.delete,name="delete"),
    path('scholar/',views.scholar,name="scholarship"),
    path('updates/<int:pk>/',views.updatescholar,name="update"),
    path('deletescholar/<int:pk>/',views.deletescholar,name="deletescholar"),
    path('NLG/<int:pk>/',views.writtentext,name="nlg"),

    

 


    
]