/*const = form =document.querySelector("form"),
        nextBtn = form.querySelector(".nextBtn"),
        backBtn = form.querySelector(".backBtn"),
        allInput = form.querySelector(".first input");


nextBtn.addEventListener("click",()=>{
	allInput.forEach(input =>{
		if(input.value != ""){
			form.classList.add('secActive');
		}
		else
		{
			form.classList.remove('secActive');

		}
	})
})


backbtn.addEventListener("click",()=> form.classList.remove('secActive'));*/


$(document).ready(function(){                     //page  1



	$("#nxt_btn").click(function(){ 
               

		console.log(true);
		document.getElementById('secPage').style.display = 'block';
		document.getElementById('firstPage').style.display = 'none';
	});
}); 

$(document).ready(function(){                    //page  2
	$("#back_btn").click(function(){ 
		console.log(true);
		document.getElementById('secPage').style.display = 'none';
		document.getElementById('firstPage').style.display = 'block';
	});
}); 

$(document).ready(function(){                   //page  2
	$("#next_btn1").click(function(){ 
		console.log(true);
		document.getElementById('thirdPage').style.display = 'block';
		document.getElementById('secPage').style.display = 'none';
	});
}); 

$(document).ready(function(){                   //page  3
	$("#back_btn1").click(function(){ 
		console.log(true);
		document.getElementById('thirdPage').style.display = 'none';
		document.getElementById('secPage').style.display = 'block';
	});
}); 

$(document).ready(function(){                    //page  3
	$("#nxt_btn2").click(function(){ 
		console.log(true);
		document.getElementById('fourPage').style.display = 'block';
		document.getElementById('thirdPage').style.display = 'none';
	});
}); 

$(document).ready(function(){                   //page  4
	$("#back_btn2").click(function(){ 
		console.log(true);
		document.getElementById('fourPage').style.display = 'none';
		document.getElementById('thirdPage').style.display = 'block';
	});
}); 








	$(document).ready(function(){                   //page  4
	$("#nxt_btn3").click(function(){ 
		let x = document.getElementById('Bro').selectedOptions[0].value;
		if(x == "NA"){
			console.log(x);
		document.getElementById('eighthPage').style.display = 'block';
		document.getElementById('fourPage').style.display = 'none';

 
		}else if(x == 1){
			console.log(true);
		document.getElementById('fifthPage').style.display = 'block';
		document.getElementById('fourPage').style.display = 'none';
		}
		else if(x == 2){
			console.log(true);
		document.getElementById('fifthPage').style.display = 'block';
		document.getElementById('fourPage').style.display = 'none';
		}
		else if(x == 3){
			console.log(true);
		document.getElementById('fifthPage').style.display = 'block';
		document.getElementById('fourPage').style.display = 'none';
		}
	}); 

});



	$(document).ready(function(){                   //page  4
	$("#nxt_btn4").click(function(){ 
		let x = document.getElementById('Bro').selectedOptions[0].value;
		if(x == 1){
			console.log(x);
		document.getElementById('eighthPage').style.display = 'block';
		document.getElementById('fifthPage').style.display = 'none';

 
		}else if(x == 2 ){
			console.log(true);
		document.getElementById('sixthPage').style.display = 'block';
		document.getElementById('fifthPage').style.display = 'none';
		
		}else if(x == 3){
			console.log(true);
		document.getElementById('sixthPage').style.display = 'block';
		document.getElementById('fifthPage').style.display = 'none';
		}
	
	}); 

});



	$(document).ready(function(){                   //page  4
	$("#nxt_btn5").click(function(){ 
		let x = document.getElementById('Bro').selectedOptions[0].value;
		if(x == 2){
			console.log(x);
		document.getElementById('eighthPage').style.display = 'block';
		document.getElementById('sixthPage').style.display = 'none';

 
		}else if(x == 3 ){
			console.log(true);
		document.getElementById('seventhPage').style.display = 'block';
		document.getElementById('sixthPage').style.display = 'none';
		}
	
	}); 

});

	$(document).ready(function(){                    //page  3
	$("#nxt_btn6").click(function(){ 
		console.log(true);
		document.getElementById('eighthPage').style.display = 'block';
		document.getElementById('seventhPage').style.display = 'none';
	});
}); 



	$(document).ready(function(){                   //page  5
	$("#back_btn3").click(function(){ 
		
		document.getElementById('fifthPage').style.display = 'none';
		document.getElementById('fourPage').style.display = 'block';

	}); 

});

	$(document).ready(function(){                   //page  6
	$("#back_btn4").click(function(){ 
 
 		document.getElementById('sixthPage').style.display = 'none';
		document.getElementById('fifthPage').style.display = 'block';

	}); 

});



$(document).ready(function(){                    //page  7
	$("#back_btn5").click(function(){ 
		console.log(true);
		document.getElementById('seventhPage').style.display = 'none';
		document.getElementById('sixthPage').style.display = 'block';
	});
}); 

 
	$(document).ready(function(){                   //page  4
	$("#back_btn6").click(function(){ 
		let x = document.getElementById('Bro').selectedOptions[0].value;
		if(x == "NA"){
			console.log(x);
		document.getElementById('eighthPage').style.display = 'none';
		document.getElementById('fourPage').style.display = 'block';

 
		}else if(x == 1){
			console.log(x);
		document.getElementById('eighthPage').style.display = 'none';
		document.getElementById('fifthPage').style.display = 'block';

 
		}else if(x == 2 ){
			console.log(true);
		document.getElementById('eighthPage').style.display = 'none';
		document.getElementById('sixthPage').style.display = 'block';
		
		}else if(x == 3 ){
			console.log(true);
		document.getElementById('eighthPage').style.display = 'none';
		document.getElementById('seventhPage').style.display = 'block';
		}

	
	}); 

});




// sister form

	$(document).ready(function(){                   //page  8
	$("#nxt_btn7").click(function(){ 
		let x = document.getElementById('Sis').selectedOptions[0].value;
		if(x == "NA"){
			console.log(x);
		document.getElementById('twelvethPage').style.display = 'block';
		document.getElementById('eighthPage').style.display = 'none';

 
		}else if(x == 1){
			console.log(true);
		document.getElementById('ninthPage').style.display = 'block';
		document.getElementById('eighthPage').style.display = 'none';
		}
		else if(x == 2){
			console.log(true);
		document.getElementById('ninthPage').style.display = 'block';
		document.getElementById('eighthPage').style.display = 'none';
		}
		else if(x == 3){
			console.log(true);
		document.getElementById('ninthPage').style.display = 'block';
		document.getElementById('eighthPage').style.display = 'none';
		}
	}); 

});




		$(document).ready(function(){                   //page  9
	$("#nxt_btn8").click(function(){ 
		let x = document.getElementById('Sis').selectedOptions[0].value;
		if(x == 1){
			console.log(x);
		document.getElementById('twelvethPage').style.display = 'block';
		document.getElementById('ninthPage').style.display = 'none';

 
		}else if(x == 2 ){
			console.log(true);
		document.getElementById('tenthPage').style.display = 'block';
		document.getElementById('ninthPage').style.display = 'none';
		
		}else if(x == 3){
			console.log(true);
		document.getElementById('tenthPage').style.display = 'block';
		document.getElementById('ninthPage').style.display = 'none';
		}
	
	}); 

});



	$(document).ready(function(){                   //page  10
	$("#nxt_btn9").click(function(){ 
		let x = document.getElementById('Sis').selectedOptions[0].value;
		if(x == 2){
			console.log(x);
		document.getElementById('twelvethPage').style.display = 'block';
		document.getElementById('tenthPage').style.display = 'none';

 
		}else if(x == 3 ){
			console.log(true);
		document.getElementById('eleventhPage').style.display = 'block';
		document.getElementById('tenthPage').style.display = 'none';
		}
	
	}); 

});

	$(document).ready(function(){                    //page  11
	$("#nxt_btn10").click(function(){ 
		console.log(true);
		document.getElementById('twelvethPage').style.display = 'block';
		document.getElementById('eleventhPage').style.display = 'none';
	});
}); 



	$(document).ready(function(){                   //page  9
	$("#back_btn7").click(function(){ 
		
		document.getElementById('ninthPage').style.display = 'none';
		document.getElementById('eighthPage').style.display = 'block';

	}); 

});

	$(document).ready(function(){                   //page  10
	$("#back_btn8").click(function(){ 
 
 		document.getElementById('tenthPage').style.display = 'none';
		document.getElementById('ninthPage').style.display = 'block';

	}); 

});



$(document).ready(function(){                    //page  11
	$("#back_btn9").click(function(){ 
		console.log(true);
		document.getElementById('eleventhPage').style.display = 'none';
		document.getElementById('tenthPage').style.display = 'block';
	});
}); 

 
	$(document).ready(function(){                   //page  12
	$("#back_btn10").click(function(){ 
		let x = document.getElementById('Sis').selectedOptions[0].value;
		if(x == "NA"){
			console.log(x);
		document.getElementById('twelvethPage').style.display = 'none';
		document.getElementById('eighthPage').style.display = 'block';

 
		}else if(x == 1){
			console.log(x);
		document.getElementById('twelvethPage').style.display = 'none';
		document.getElementById('ninthPage').style.display = 'block';

 
		}else if(x == 2 ){
			console.log(true);
		document.getElementById('twelvethPage').style.display = 'none';
		document.getElementById('tenthPage').style.display = 'block';
		
		}else if(x == 3 ){
			console.log(true);
		document.getElementById('twelvethPage').style.display = 'none';
		document.getElementById('eleventhPage').style.display = 'block';
		}

	
	}); 

});



$(document).ready(function(){                    //page  12
	$("#nxt_btn11").click(function(){ 
		console.log(true);
		document.getElementById('thirteenthPage').style.display = 'block';
		document.getElementById('twelvethPage').style.display = 'none';
	});
}); 



$(document).ready(function(){                    //page  13
	$("#back_btn11").click(function(){ 
		console.log(true);
		document.getElementById('thirteenthPage').style.display = 'none';
		document.getElementById('twelvethPage').style.display = 'block';
	});
}); 



$(document).ready(function(){                    //page  13
	$("#nxt_btn12").click(function(){ 
		console.log(true);
		document.getElementById('fourteenthPage').style.display = 'block';
		document.getElementById('thirteenthPage').style.display = 'none';
	});
}); 


$(document).ready(function(){                    //page  14
	$("#back_btn12").click(function(){ 
		console.log(true);
		document.getElementById('fourteenthPage').style.display = 'none';
		document.getElementById('thirteenthPage').style.display = 'block';
	});
}); 



$(document).ready(function(){                    //page  14
	$("#nxt_btn13").click(function(){ 
		console.log(true);
		document.getElementById('fifteenthPage').style.display = 'block';
		document.getElementById('fourteenthPage').style.display = 'none';
	});
}); 


$(document).ready(function(){                    //page  15
	$("#back_btn13").click(function(){ 
		console.log(true);
		document.getElementById('fifteenthPage').style.display = 'none';
		document.getElementById('fourteenthPage').style.display = 'block';
	});
}); 



$(document).ready(function(){                    //page  15
	$("#nxt_btn14").click(function(){ 
		console.log(true);
		document.getElementById('sixteenthPage').style.display = 'block';
		document.getElementById('fifteenthPage').style.display = 'none';
	});
}); 


$(document).ready(function(){                    //page  16
	$("#back_btn14").click(function(){ 
		console.log(true);
		document.getElementById('sixteenthPage').style.display = 'none';
		document.getElementById('fifteenthPage').style.display = 'block';
	});
}); 


$(document).ready(function(){
	$("#nxt_btn15").click(function(){ 
	window.location.href = "C:\Users\Sharan\project\templates\home.html";
});
});

var dec=document.getElementById('dec');

const cb = document.querySelector('#dec');
console.log(cb.checked);

//data insertion

$(document).ready(function(){
	$(".finnal_submit").click(function(){ 
		  
		var a=document.getElementById('1');
		var b=document.getElementById('2');
		var c=document.getElementById('3');
		var d=document.getElementById('4');
		var e=document.getElementById('5');
		var f=document.getElementById('6');
		var g=document.getElementById('7');
		var h=document.getElementById('8');
		var i=document.getElementById('9');
		var j=document.getElementById('10');
		var k=document.getElementById('11');

		$.ajax({
			url: "C:\Users\Sharan\project\scholars\views.py",
			method: "POST",        
			data: { 
				"field1": "hello",
				"field2": "hello1"
			  },
			  success: function (response) {
				alert("Success !!");
			  },
			  error: function () {
				alert("Error !!");
			  }
			})
		});
});